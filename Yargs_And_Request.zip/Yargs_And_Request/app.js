const yargs = require('yargs');
const backend = require('./backend');

yargs.command({
    command:'Get',
    describe:'Get the temperature',
    builder:{
        cityname:{
            describe:'Please provide city name',
            demandOption: true,
            type:'string'
        }
    },
    handler:function(argv){
        backend.getCity(argv.cityname)
        
    }
})

yargs.parse();
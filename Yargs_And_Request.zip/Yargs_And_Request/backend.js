const request = require('request');
const mapboxToken = 'pk.eyJ1IjoiaGFyc2hzaHJpdmFzdGF2YSIsImEiOiJjand0YWE1Y3gwNDZpNDVvNWVyeXNkbWluIn0.FKuTLd-JpcHyh1dsAV98nQ'
const darkToken = '394d1c68d9d7b27fbf885f7c136601bb';
var lat; var long; var placeName;
const getCity = (cityname) => {
    const url = "https://api.mapbox.com/geocoding/v5/mapbox.places/" + cityname + ".json?access_token=" + mapboxToken;
    request({ url: url, json: true }, (error, response) => {
        if (error) {
            console.log('Unable to connect to location service')
        }
        if (response.body.features.length === 0) {
            console.log('Unable to find location, try another search.')
        }
        else {
            dlat = response.body.features[0].center[0];
            dlong = response.body.features[0].center[1];
            dplaceName = response.body.features[0].place_name;
            getWeather(dlat, dlong, dplaceName)
        } 

    })
}

const getWeather = (lat, long, placeName) => {
    const url = 'https://api.darksky.net/forecast/' + darkToken + '/' + long + ',' + lat + '?units=si';
    request({ url: url, json: true }, (error, response) => {
        if (error) {
            console.log('Unable to connect to weather server')
        }
        else if (response.body.error) {
            console.log('Unable to find the temperature for given location')
        }
        else {
            console.log("Temperature : " + response.body.currently.temperature)
        }
    })
}
module.exports = {
    getCity
}